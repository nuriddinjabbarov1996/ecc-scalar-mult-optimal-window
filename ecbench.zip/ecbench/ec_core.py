"""
ec_core.py — elliptik egri chiziq arifmetikasi (qisqa Veyershtrass shakli, Fp).

* Jacobian koordinatalar: (X, Y, Z) -> affin (X/Z^2, Y/Z^3); cheksizlik nuqtasi = None.
* Formulalar Explicit-Formulas Database (EFD, Bernstein–Lange) dan olingan:
    - dbl-2009-l   (a = 0)   : 2M + 5S
    - dbl-2001-b   (a = -3)  : 3M + 5S
    - dbl-2007-bl  (umumiy a): 1M + 8S + 1*a
    - add-2007-bl  (J + J)   : 11M + 5S
    - madd-2007-bl (J + A)   : 7M + 4S
* gmpy2 o'rnatilgan bo'lsa, maydon elementlari mpz bo'ladi (2–4 marta tezroq).
* CountingCurve — har bir amalni sanaydigan variant (vaqt o'lchashda ishlatilmaydi).
"""
from __future__ import annotations

try:
    import gmpy2
    from gmpy2 import mpz
    HAVE_GMPY2 = True

    def _inv(x, p):
        return gmpy2.invert(x, p)
except ImportError:  # sof Python
    HAVE_GMPY2 = False
    mpz = int

    def _inv(x, p):
        return pow(x, -1, p)


# --------------------------------------------------------------------------- #
#  Egri chiziq parametrlari
# --------------------------------------------------------------------------- #
CURVES = {
    "secp256k1": dict(
        p=2**256 - 2**32 - 977,
        a=0,
        b=7,
        n=0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141,
        Gx=0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798,
        Gy=0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8,
        # GLV endomorfizmi: phi(x, y) = (beta*x, y) = [lam]P
        lam=0x5363AD4CC05C30E0A5261C028812645A122E22EA20816678DF02967C1B23BD72,
        beta=0x7AE96A2B657C07106E64479EAC3434E99CF0497512F58995C1396C28719501EE,
    ),
    "P-256": dict(
        p=2**256 - 2**224 + 2**192 + 2**96 - 1,
        a=-3,
        b=0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B,
        n=0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551,
        Gx=0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296,
        Gy=0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5,
    ),
    # O'quv egri chizig'i (faqat to'g'rilik testi uchun): y^2 = x^3 + 2x + 2 (mod 17)
    "toy17": dict(p=17, a=2, b=2, n=19, Gx=5, Gy=1),
}


class Curve:
    """Jacobian arifmetikasi (sanash yo'q — vaqt o'lchash uchun)."""

    def __init__(self, name: str):
        c = CURVES[name]
        self.name = name
        self.p = mpz(c["p"])
        self.a_int = c["a"]
        self.a = mpz(c["a"] % c["p"])
        self.b = mpz(c["b"])
        self.n = int(c["n"])
        self.G = (mpz(c["Gx"]), mpz(c["Gy"]))
        self.lam = c.get("lam")
        self.beta = mpz(c["beta"]) if "beta" in c else None
        self.field_bytes = (int(self.p).bit_length() + 7) // 8
        if self.a_int == 0:
            self.dbl = self._dbl_a0
        elif self.a_int == -3:
            self.dbl = self._dbl_am3
        else:
            self.dbl = self._dbl_gen

    # ------------------------------------------------------------------ #
    def on_curve(self, P) -> bool:
        if P is None:
            return True
        x, y = P
        p = self.p
        return (y * y - (x * x * x + self.a * x + self.b)) % p == 0

    @staticmethod
    def to_jac(P):
        return None if P is None else (P[0], P[1], mpz(1))

    def neg_aff(self, P):
        return None if P is None else (P[0], (-P[1]) % self.p)

    def to_affine(self, J):
        if J is None:
            return None
        X, Y, Z = J
        p = self.p
        zi = _inv(Z, p)
        zi2 = zi * zi % p
        return (X * zi2 % p, Y * zi2 * zi % p)

    def batch_to_affine(self, Js):
        """Montgomery hiylasi: n ta nuqta uchun 1 ta inversiya + 3(n-1) M, keyin har biriga 1S+3M."""
        p = self.p
        pts = [J for J in Js]
        if not pts:
            return []
        acc = [None] * len(pts)
        prod = mpz(1)
        for i, J in enumerate(pts):
            acc[i] = prod
            prod = prod * J[2] % p
        inv = _inv(prod, p)
        out = [None] * len(pts)
        for i in range(len(pts) - 1, -1, -1):
            X, Y, Z = pts[i]
            zi = inv * acc[i] % p
            inv = inv * Z % p
            zi2 = zi * zi % p
            out[i] = (X * zi2 % p, Y * zi2 * zi % p)
        return out

    # ------------------------- ikkilantirish -------------------------- #
    def _dbl_a0(self, J):  # dbl-2009-l
        if J is None:
            return None
        X1, Y1, Z1 = J
        if Y1 == 0:
            return None
        p = self.p
        A = X1 * X1 % p
        B = Y1 * Y1 % p
        C = B * B % p
        t = X1 + B
        D = 2 * (t * t - A - C) % p
        E = 3 * A % p
        F = E * E % p
        X3 = (F - 2 * D) % p
        Y3 = (E * (D - X3) - 8 * C) % p
        Z3 = 2 * Y1 * Z1 % p
        return (X3, Y3, Z3)

    def _dbl_am3(self, J):  # dbl-2001-b
        if J is None:
            return None
        X1, Y1, Z1 = J
        if Y1 == 0:
            return None
        p = self.p
        delta = Z1 * Z1 % p
        gamma = Y1 * Y1 % p
        beta = X1 * gamma % p
        alpha = 3 * (X1 - delta) * (X1 + delta) % p
        X3 = (alpha * alpha - 8 * beta) % p
        t = Y1 + Z1
        Z3 = (t * t - gamma - delta) % p
        Y3 = (alpha * (4 * beta - X3) - 8 * gamma * gamma) % p
        return (X3, Y3, Z3)

    def _dbl_gen(self, J):  # dbl-2007-bl
        if J is None:
            return None
        X1, Y1, Z1 = J
        if Y1 == 0:
            return None
        p = self.p
        XX = X1 * X1 % p
        YY = Y1 * Y1 % p
        YYYY = YY * YY % p
        ZZ = Z1 * Z1 % p
        t = X1 + YY
        S = 2 * (t * t - XX - YYYY) % p
        M = (3 * XX + self.a * ZZ * ZZ) % p
        T = (M * M - 2 * S) % p
        Y3 = (M * (S - T) - 8 * YYYY) % p
        t = Y1 + Z1
        Z3 = (t * t - YY - ZZ) % p
        return (T, Y3, Z3)

    # --------------------------- qo'shish ----------------------------- #
    def add(self, J1, J2):  # add-2007-bl
        if J1 is None:
            return J2
        if J2 is None:
            return J1
        X1, Y1, Z1 = J1
        X2, Y2, Z2 = J2
        p = self.p
        Z1Z1 = Z1 * Z1 % p
        Z2Z2 = Z2 * Z2 % p
        U1 = X1 * Z2Z2 % p
        U2 = X2 * Z1Z1 % p
        S1 = Y1 * Z2 * Z2Z2 % p
        S2 = Y2 * Z1 * Z1Z1 % p
        H = (U2 - U1) % p
        r = 2 * (S2 - S1) % p
        if H == 0:
            if r == 0:
                return self.dbl(J1)
            return None
        I = 4 * H * H % p
        Jv = H * I % p
        V = U1 * I % p
        X3 = (r * r - Jv - 2 * V) % p
        Y3 = (r * (V - X3) - 2 * S1 * Jv) % p
        t = Z1 + Z2
        Z3 = (t * t - Z1Z1 - Z2Z2) * H % p
        return (X3, Y3, Z3)

    def madd(self, J1, A2):  # madd-2007-bl, A2 affin
        if A2 is None:
            return J1
        if J1 is None:
            return (A2[0], A2[1], mpz(1))
        X1, Y1, Z1 = J1
        X2, Y2 = A2
        p = self.p
        Z1Z1 = Z1 * Z1 % p
        U2 = X2 * Z1Z1 % p
        S2 = Y2 * Z1 * Z1Z1 % p
        H = (U2 - X1) % p
        r = 2 * (S2 - Y1) % p
        if H == 0:
            if r == 0:
                return self.dbl(J1)
            return None
        HH = H * H % p
        I = 4 * HH
        Jv = H * I % p
        V = X1 * I % p
        X3 = (r * r - Jv - 2 * V) % p
        Y3 = (r * (V - X3) - 2 * Y1 * Jv) % p
        t = Z1 + H
        Z3 = (t * t - Z1Z1 - HH) % p
        return (X3, Y3, Z3)

    def phi_aff(self, P):
        """GLV endomorfizmi (faqat secp256k1): (x, y) -> (beta*x, y)."""
        return (self.beta * P[0] % self.p, P[1])

    # --------------------- etalon (sekin, affin) ---------------------- #
    def ref_mul(self, k: int, P):
        """Etalon: affin double-and-add (Fermat inversiyasi bilan) — faqat test uchun."""
        p = int(self.p)
        a = int(self.a)

        def add(A, B):
            if A is None:
                return B
            if B is None:
                return A
            x1, y1 = A
            x2, y2 = B
            if x1 == x2:
                if (y1 + y2) % p == 0:
                    return None
                l = (3 * x1 * x1 + a) * pow(2 * y1, p - 2, p) % p
            else:
                l = (y2 - y1) * pow(x2 - x1, p - 2, p) % p
            x3 = (l * l - x1 - x2) % p
            return (x3, (l * (x1 - x3) - y1) % p)

        R = None
        Q = (int(P[0]), int(P[1]))
        for bit in bin(k)[2:]:
            R = add(R, R)
            if bit == "1":
                R = add(R, Q)
        return R


# Har bir formulaning maydon amallari soni (M, S) — xarajatni M ekvivalentida baholash uchun
FIELD_COST = {
    "dbl_a0": (2, 5),
    "dbl_am3": (3, 5),
    "dbl_gen": (1, 8),
    "add": (11, 5),
    "madd": (7, 4),
    "norm_pt": (6, 1),  # Montgomery hiylasi: 3M + konvertatsiya 3M + 1S (taxminiy)
    "phi": (1, 0),
}

OPS = ("dbl", "add", "madd", "inv", "norm_pt", "phi")


class CountingCurve(Curve):
    """Amallar sonini sanaydigan variant."""

    def __init__(self, name: str):
        super().__init__(name)
        self.reset()
        self._raw_dbl = self.dbl
        self.dbl = self._count_dbl

    def reset(self):
        self.cnt = {k: 0 for k in OPS}

    def snapshot(self):
        return dict(self.cnt)

    def _count_dbl(self, J):
        if J is not None:
            self.cnt["dbl"] += 1
        return self._raw_dbl(J)

    def add(self, J1, J2):
        if J1 is not None and J2 is not None:
            self.cnt["add"] += 1
        return super().add(J1, J2)

    def madd(self, J1, A2):
        if J1 is not None and A2 is not None:
            self.cnt["madd"] += 1
        return super().madd(J1, A2)

    def to_affine(self, J):
        if J is not None:
            self.cnt["inv"] += 1
        return super().to_affine(J)

    def batch_to_affine(self, Js):
        if Js:
            self.cnt["inv"] += 1
            self.cnt["norm_pt"] += len(Js)
        return super().batch_to_affine(Js)

    def phi_aff(self, P):
        self.cnt["phi"] += 1
        return super().phi_aff(P)


def dbl_kind(curve: Curve) -> str:
    return {0: "dbl_a0", -3: "dbl_am3"}.get(curve.a_int, "dbl_gen")


def field_cost_M(curve: Curve, counts: dict, s_ratio: float = 0.8, i_ratio: float = 100.0) -> float:
    """Amallar sonidan maydon ko'paytirishlari ekvivalentidagi xarajat (S = s_ratio*M, I = i_ratio*M)."""
    tot = 0.0
    m, s = FIELD_COST[dbl_kind(curve)]
    tot += counts.get("dbl", 0) * (m + s_ratio * s)
    for op in ("add", "madd", "norm_pt", "phi"):
        m, s = FIELD_COST[op]
        tot += counts.get(op, 0) * (m + s_ratio * s)
    tot += counts.get("inv", 0) * i_ratio
    return tot
