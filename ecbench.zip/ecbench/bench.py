"""
bench.py — yagona tajriba bazasini yaratadi.

Ishga tushirish:
    python bench.py                 # to'liq tajriba (bir necha o'n daqiqa)
    python bench.py --quick         # 2–3 daqiqalik sinov

Natijalar (results_raw/ papkasida):
    env.json        — kompyuter, Python, kutubxona versiyalari
    tests.csv       — to'g'rilik testlari
    raw.csv         — har bir alohida vaqt o'lchovi (ns): kodlash, oldindan hisoblash, asosiy sikl
    counts.csv      — har bir (skalyar, algoritm) uchun guruh amallari soni
    memory.csv      — jadval hajmi: nazariy (payload) va tracemalloc bo'yicha o'lchangan
"""
from __future__ import annotations

import argparse
import csv
import gc
import json
import os
import platform
import random
import sys
import time
import tracemalloc
from datetime import datetime

import ec_core
from ec_core import Curve, CountingCurve, HAVE_GMPY2
from algorithms import build_algorithms, WNAF

perf = time.perf_counter_ns


# --------------------------------------------------------------------------- #
#  Real kutubxonalar (ixtiyoriy)
# --------------------------------------------------------------------------- #
class LibOpenSSL:
    """cryptography (OpenSSL) orqali. variable: ECDH (k*Q ning x koordinatasi); fixed: k*G (kalit yaratish)."""

    def __init__(self, curve_name, scenario):
        from cryptography.hazmat.primitives.asymmetric import ec

        self.ec = ec
        self.cobj = {"secp256k1": ec.SECP256K1(), "P-256": ec.SECP256R1()}[curve_name]
        self.scenario = scenario
        self.label = "OpenSSL"
        self.name = "OpenSSL"
        self.w = None

    def setup(self, k, P):
        ec = self.ec
        if self.scenario == "variable":
            priv = ec.derive_private_key(k, self.cobj)
            pub = ec.EllipticCurvePublicNumbers(int(P[0]), int(P[1]), self.cobj).public_key()
            return (priv, pub)
        return k

    def timed(self, state):
        if self.scenario == "variable":
            priv, pub = state
            return priv.exchange(self.ec.ECDH(), pub)
        return self.ec.derive_private_key(state, self.cobj)

    def result_x(self, out):
        if self.scenario == "variable":
            return int.from_bytes(out, "big")
        return out.public_key().public_numbers().x


class LibSecp256k1:
    """coincurve (libsecp256k1) orqali, faqat secp256k1."""

    def __init__(self, curve_name, scenario):
        import coincurve

        self.cc = coincurve
        self.scenario = scenario
        self.label = "libsecp256k1"
        self.name = "libsecp256k1"
        self.w = None

    def setup(self, k, P):
        kb = k.to_bytes(32, "big")
        if self.scenario == "variable":
            pb = b"\x04" + int(P[0]).to_bytes(32, "big") + int(P[1]).to_bytes(32, "big")
            return (self.cc.PublicKey(pb), kb)
        return kb

    def timed(self, state):
        if self.scenario == "variable":
            pub, kb = state
            return pub.multiply(kb)
        return self.cc.PublicKey.from_secret(state)

    def result_x(self, out):
        return out.point()[0]


def load_libs(curve_name, scenario, log):
    libs = []
    try:
        libs.append(LibOpenSSL(curve_name, scenario))
    except Exception as e:  # pragma: no cover
        log(f"  [!] OpenSSL (cryptography) topilmadi: {e}")
    if curve_name == "secp256k1":
        try:
            libs.append(LibSecp256k1(curve_name, scenario))
        except Exception as e:
            log(f"  [!] coincurve (libsecp256k1) topilmadi: {e}  -> pip install coincurve")
    return libs


# --------------------------------------------------------------------------- #
def env_info():
    info = dict(
        date=datetime.now().isoformat(timespec="seconds"),
        python=sys.version,
        implementation=platform.python_implementation(),
        platform=platform.platform(),
        machine=platform.machine(),
        processor=platform.processor(),
        cpu_count=os.cpu_count(),
        gmpy2=None,
        cryptography=None,
        openssl=None,
        coincurve=None,
    )
    try:
        import gmpy2

        info["gmpy2"] = gmpy2.version()
    except Exception:
        pass
    try:
        import cryptography
        from cryptography.hazmat.backends.openssl.backend import backend

        info["cryptography"] = cryptography.__version__
        info["openssl"] = backend.openssl_version_text()
    except Exception:
        pass
    try:
        import coincurve

        info["coincurve"] = getattr(coincurve, "__version__", "installed")
    except Exception:
        pass
    # CPU nomi (Linux / Windows / macOS)
    try:
        if sys.platform.startswith("linux"):
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if "model name" in line:
                        info["cpu_model"] = line.split(":", 1)[1].strip()
                        break
        elif sys.platform == "darwin":
            import subprocess

            info["cpu_model"] = subprocess.check_output(
                ["sysctl", "-n", "machdep.cpu.brand_string"]).decode().strip()
        elif sys.platform == "win32":
            info["cpu_model"] = platform.processor()
    except Exception:
        pass
    return info


def rand_scalar(rnd, t, n):
    """Aniq t bitli (yuqori biti 1) va n dan kichik tasodifiy skalyar."""
    while True:
        k = rnd.getrandbits(t) | (1 << (t - 1))
        if 1 <= k < n:
            return k


# --------------------------------------------------------------------------- #
def correctness_tests(args, log):
    rows = []
    rnd = random.Random(args.seed + 999)
    toy = Curve("toy17")
    ok = toy.ref_mul(13, toy.G) == (16, 4)
    rows.append(dict(curve="toy17", algo="reference", t=4, k=13, ok=int(ok)))
    for cn in args.curves:
        c = Curve(cn)
        for scen in args.scenarios:
            algs = build_algorithms(cn, scen, args.wnaf, args.fw, args.glv, args.comb)
            libs = load_libs(cn, scen, log) if not args.no_libs else []
            for trial in range(args.tests):
                t = rnd.choice(args.lengths)
                k = rand_scalar(rnd, t, c.n)
                P = c.G if scen == "fixed" else c.to_affine(WNAF(5).run(c, rnd.randrange(1, c.n), c.G))
                ref = c.ref_mul(k, P)
                for a in algs:
                    r = c.to_affine(a.run(c, k, P))
                    good = (int(r[0]), int(r[1])) == ref and c.on_curve(r)
                    rows.append(dict(curve=cn, scenario=scen, algo=a.label, t=t, k=hex(k), ok=int(good)))
                for L in libs:
                    out = L.timed(L.setup(k, P))
                    good = L.result_x(out) == ref[0]
                    rows.append(dict(curve=cn, scenario=scen, algo=L.label, t=t, k=hex(k), ok=int(good)))
    return rows


def write_csv(path, rows, fields=None):
    if not rows:
        return
    fields = fields or list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


# --------------------------------------------------------------------------- #
def run(args):
    os.makedirs(args.out, exist_ok=True)
    logf = open(os.path.join(args.out, "log.txt"), "w", encoding="utf-8")

    def log(msg):
        print(msg, flush=True)
        logf.write(msg + "\n")

    env = env_info()
    env["args"] = vars(args)
    with open(os.path.join(args.out, "env.json"), "w", encoding="utf-8") as f:
        json.dump(env, f, indent=2, default=str)
    log(f"Python {platform.python_version()} | gmpy2: {env['gmpy2']} | OpenSSL: {env['openssl']} | coincurve: {env['coincurve']}")
    if not HAVE_GMPY2:
        log("[!] gmpy2 o'rnatilmagan — sof Python bilan ishlanadi. Tavsiya: pip install gmpy2")

    # 1) To'g'rilik testlari
    log("1) To'g'rilik testlari...")
    tests = correctness_tests(args, log)
    write_csv(os.path.join(args.out, "tests.csv"), tests,
              ["curve", "scenario", "algo", "t", "k", "ok"])
    nfail = sum(1 for r in tests if not r["ok"])
    log(f"   {len(tests)} ta test, xato: {nfail}")
    if nfail:
        log("[X] Xato topildi — tajriba to'xtatildi. tests.csv ni yuboring.")
        return

    raw_rows, count_rows, mem_rows = [], [], []
    rnd = random.Random(args.seed)
    t_start = time.time()

    for cn in args.curves:
        c = Curve(cn)
        cc = CountingCurve(cn)
        fb = c.field_bytes
        for scen in args.scenarios:
            algs = build_algorithms(cn, scen, args.wnaf, args.fw, args.glv, args.comb)
            libs = load_libs(cn, scen, log) if not args.no_libs else []
            lengths = args.lengths if scen == "variable" else args.fixed_lengths

            # 2) Xotira (bir marta, har bir algoritm uchun)
            P0 = c.G
            for a in algs:
                gc.collect()
                tracemalloc.start()
                tab = a.precompute(c, P0)
                cur, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                del tab
                mem_rows.append(dict(curve=cn, scenario=scen, algo=a.name, w=a.w or 0, label=a.label,
                                     table_points=a.table_points(c),
                                     table_bytes_payload=a.table_points(c) * 2 * fb,
                                     tracemalloc_current=cur, tracemalloc_peak=peak))

            for t in lengths:
                scalars = [rand_scalar(rnd, t, c.n) for _ in range(args.nscalars)]
                if scen == "variable":
                    bases = [c.to_affine(WNAF(5).run(c, rnd.randrange(1, c.n), c.G)) for _ in scalars]
                else:
                    bases = [c.G] * len(scalars)

                # 3) Amallar soni (CountingCurve)
                for sid, (k, P) in enumerate(zip(scalars, bases)):
                    for a in algs:
                        cc.reset()
                        rec = a.recode(k, cc)
                        tab = a.precompute(cc, P)
                        pre = cc.snapshot()
                        cc.reset()
                        a.main(cc, rec, tab)
                        mn = cc.snapshot()
                        row = dict(curve=cn, scenario=scen, t=t, scalar_id=sid, algo=a.name,
                                   w=a.w or 0, label=a.label, table_points=a.table_points(c))
                        row.update({f"pre_{k_}": v for k_, v in pre.items()})
                        row.update({f"main_{k_}": v for k_, v in mn.items()})
                        count_rows.append(row)

                # 4) Vaqt o'lchovlari
                lib_states = {(L.label, sid): L.setup(k, P) for L in libs
                              for sid, (k, P) in enumerate(zip(scalars, bases))}
                configs = list(algs) + list(libs)
                # isinish (warm-up)
                for cfg in configs:
                    for _ in range(args.warmup):
                        if hasattr(cfg, "timed"):
                            cfg.timed(lib_states[(cfg.label, 0)])
                        else:
                            cfg.run(c, scalars[0], bases[0])
                gc.collect()
                gc.disable()
                try:
                    for rep in range(args.reps):
                        for sid, (k, P) in enumerate(zip(scalars, bases)):
                            order = configs[:]
                            rnd.shuffle(order)
                            for cfg in order:
                                if hasattr(cfg, "timed"):
                                    st = lib_states[(cfg.label, sid)]
                                    t0 = perf()
                                    cfg.timed(st)
                                    t3 = perf()
                                    trec = tpre = 0
                                    tmain = t3 - t0
                                    name, w = cfg.name, 0
                                else:
                                    t0 = perf()
                                    rec = cfg.recode(k, c)
                                    t1 = perf()
                                    tab = cfg.precompute(c, P)
                                    t2 = perf()
                                    cfg.main(c, rec, tab)
                                    t3 = perf()
                                    trec, tpre, tmain = t1 - t0, t2 - t1, t3 - t2
                                    name, w = cfg.name, cfg.w or 0
                                raw_rows.append(dict(curve=cn, scenario=scen, t=t, scalar_id=sid, rep=rep,
                                                     algo=name, w=w, label=cfg.label,
                                                     t_rec_ns=trec, t_pre_ns=tpre, t_main_ns=tmain,
                                                     t_total_ns=trec + tpre + tmain))
                        if rep % max(1, args.reps // 5) == 0:
                            gc.enable(); gc.collect(); gc.disable()
                finally:
                    gc.enable()
                el = time.time() - t_start
                log(f"   {cn:9s} {scen:8s} t={t:3d}: {len(configs)} konfiguratsiya, "
                    f"{args.nscalars} skalyar x {args.reps} takror  [{el/60:.1f} daq]")

    write_csv(os.path.join(args.out, "raw.csv"), raw_rows)
    # counts: barcha kalitlarni birlashtirish
    keys = []
    for r in count_rows:
        for k_ in r:
            if k_ not in keys:
                keys.append(k_)
    for r in count_rows:
        for k_ in keys:
            r.setdefault(k_, 0)
    write_csv(os.path.join(args.out, "counts.csv"), count_rows, keys)
    write_csv(os.path.join(args.out, "memory.csv"), mem_rows)
    log(f"Tayyor. {len(raw_rows)} ta vaqt o'lchovi. Jami vaqt: {(time.time()-t_start)/60:.1f} daqiqa.")
    log(f"Keyingi qadam: python analyze.py --raw {args.out}")
    logf.close()


def parse():
    ap = argparse.ArgumentParser(description="ECC skalyar ko'paytirish benchmarki")
    ap.add_argument("--curves", default="secp256k1,P-256")
    ap.add_argument("--scenarios", default="variable,fixed")
    ap.add_argument("--lengths", default="64,128,192,256", help="variable bazali stsenariy uchun skalyar uzunliklari")
    ap.add_argument("--fixed-lengths", default="256")
    ap.add_argument("--wnaf", default="2,3,4,5,6,7,8")
    ap.add_argument("--fw", default="2,3,4,5,6")
    ap.add_argument("--glv", default="3,4,5,6")
    ap.add_argument("--comb", default="2,3,4,5,6,7,8")
    ap.add_argument("--nscalars", type=int, default=50)
    ap.add_argument("--reps", type=int, default=20)
    ap.add_argument("--warmup", type=int, default=3)
    ap.add_argument("--tests", type=int, default=20)
    ap.add_argument("--seed", type=int, default=20261102)
    ap.add_argument("--out", default="results_raw")
    ap.add_argument("--no-libs", action="store_true")
    ap.add_argument("--quick", action="store_true", help="tez sinov rejimi")
    a = ap.parse_args()
    if a.quick:
        a.nscalars, a.reps, a.tests, a.warmup = 6, 3, 4, 1
    to_ints = lambda s: [int(x) for x in s.split(",") if x]
    a.curves = a.curves.split(",")
    a.scenarios = a.scenarios.split(",")
    a.lengths = to_ints(a.lengths)
    a.fixed_lengths = to_ints(a.fixed_lengths)
    a.wnaf, a.fw, a.glv, a.comb = map(to_ints, (a.wnaf, a.fw, a.glv, a.comb))
    return a


if __name__ == "__main__":
    run(parse())
