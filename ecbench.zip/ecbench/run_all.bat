@echo off
cd /d "%~dp0"
REM Windows uchun: barcha bosqichlarni ketma-ket bajaradi
python -m pip install -r requirements.txt
python bench.py --quick --out results_quick
python bench.py --out results_raw
python analyze.py --raw results_raw --out results
echo.
echo Tayyor. "results" va "results_raw" papkalarini zip qilib yuboring.
pause
