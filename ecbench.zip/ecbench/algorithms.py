"""
algorithms.py — skalyar ko'paytirish algoritmlari.

Har bir algoritm uch bosqichga ajratilgan (vaqti alohida o'lchanadi):
    recode(k)              -> skalyarni kodlash (raqamlar ketma-ketligi)
    precompute(curve, P)   -> oldindan hisoblangan jadval (affin nuqtalar)
    main(curve, rec, tab)  -> asosiy sikl, Jacobian natija

Algoritmlar:
    Binary      — chapdan o'ngga double-and-add
    wNAF(w)     — w = 2 bo'lsa NAF; jadval: P, 3P, ..., (2^(w-1)-1)P  (2^(w-2) nuqta)
    FW(w)       — belgisiz Fixed-window (k-ary); jadval: P, 2P, ..., (2^w-1)P
    Ladder      — Montgomery ladder (muntazam tuzilma; Python'da doimiy vaqtli EMAS)
    GLV(w)      — secp256k1 endomorfizmi + ikki wNAF ning interleaving'i
    Comb(w)     — Lim–Lee comb, faqat fiksirlangan bazaviy nuqta (G) uchun
"""
from __future__ import annotations

from math import isqrt


# --------------------------------------------------------------------------- #
#  Kodlash funksiyalari
# --------------------------------------------------------------------------- #
def wnaf_digits(k: int, w: int):
    """Standart wNAF (Hankerson et al., Alg. 3.35). LSB birinchi."""
    digits = []
    full = 1 << w
    half = 1 << (w - 1)
    while k > 0:
        if k & 1:
            d = k & (full - 1)
            if d >= half:
                d -= full
            k -= d
        else:
            d = 0
        digits.append(d)
        k >>= 1
    return digits


def binary_digits(k: int):
    return [int(b) for b in reversed(bin(k)[2:])]  # LSB birinchi


def _neg_table(curve, tab):
    p = curve.p
    return [(x, (-y) % p) for (x, y) in tab]


def _main_signed(curve, digits, tab, ntab):
    """Imzoli raqamlar uchun umumiy asosiy sikl (MSB dan). Jadvalda faqat toq karralar."""
    dbl, madd = curve.dbl, curve.madd
    R = None
    for d in reversed(digits):
        R = dbl(R)
        if d > 0:
            R = madd(R, tab[d >> 1])
        elif d < 0:
            R = madd(R, ntab[(-d) >> 1])
    return R


# --------------------------------------------------------------------------- #
class Algorithm:
    name = "base"
    w = None
    needs_fixed_base = False
    only_curves = None  # masalan {"secp256k1"}

    @property
    def label(self):
        return self.name if self.w is None else f"{self.name}(w={self.w})"

    def table_points(self, curve) -> int:
        """P ning o'zidan tashqari saqlanadigan qo'shimcha nuqtalar soni."""
        return 0

    def run(self, curve, k, P):
        rec = self.recode(k, curve)
        tab = self.precompute(curve, P)
        return self.main(curve, rec, tab)


class Binary(Algorithm):
    name = "Binary"

    def recode(self, k, curve):
        return binary_digits(k)

    def precompute(self, curve, P):
        return ([P], None)

    def main(self, curve, rec, tab):
        P = tab[0][0]
        dbl, madd = curve.dbl, curve.madd
        R = None
        for b in reversed(rec):
            R = dbl(R)
            if b:
                R = madd(R, P)
        return R


class WNAF(Algorithm):
    name = "wNAF"

    def __init__(self, w: int):
        assert w >= 2
        self.w = w

    @property
    def label(self):
        return "NAF" if self.w == 2 else f"wNAF(w={self.w})"

    def table_points(self, curve):
        return (1 << (self.w - 2)) - 1

    def recode(self, k, curve):
        return wnaf_digits(k, self.w)

    def precompute(self, curve, P):
        n = 1 << (self.w - 2)
        if n == 1:
            tab = [P]
        else:
            Pj = curve.to_jac(P)
            P2 = curve.dbl(Pj)
            cur = Pj
            jac = []
            for _ in range(n - 1):
                cur = curve.add(cur, P2)
                jac.append(cur)
            tab = [P] + curve.batch_to_affine(jac)
        return (tab, _neg_table(curve, tab))

    def main(self, curve, rec, tab):
        return _main_signed(curve, rec, tab[0], tab[1])


class FixedWindow(Algorithm):
    name = "FW"

    def __init__(self, w: int):
        assert w >= 2
        self.w = w

    def table_points(self, curve):
        return (1 << self.w) - 2

    def recode(self, k, curve):
        w = self.w
        mask = (1 << w) - 1
        digits = []
        while k > 0:
            digits.append(k & mask)
            k >>= w
        return digits  # LSB birinchi

    def precompute(self, curve, P):
        m = (1 << self.w) - 1
        Pj = curve.to_jac(P)
        cur = curve.dbl(Pj)
        jac = [cur]
        for _ in range(3, m + 1):
            cur = curve.madd(cur, P)
            jac.append(cur)
        return ([P] + curve.batch_to_affine(jac), None)

    def main(self, curve, rec, tab):
        tab = tab[0]
        w = self.w
        dbl, madd = curve.dbl, curve.madd
        R = None
        for d in reversed(rec):
            if R is not None:
                for _ in range(w):
                    R = dbl(R)
            if d:
                R = madd(R, tab[d - 1])
        return R


class Ladder(Algorithm):
    name = "Ladder"

    def recode(self, k, curve):
        return bin(k)[2:]

    def precompute(self, curve, P):
        return ([P], None)

    def main(self, curve, rec, tab):
        P = tab[0][0]
        add, dbl = curve.add, curve.dbl
        R0 = curve.to_jac(P)
        R1 = dbl(R0)
        for b in rec[1:]:
            if b == "1":
                R0 = add(R0, R1)
                R1 = dbl(R1)
            else:
                R1 = add(R0, R1)
                R0 = dbl(R0)
        return R0


# --------------------------------------------------------------------------- #
#  GLV (secp256k1)
# --------------------------------------------------------------------------- #
def glv_basis(n: int, lam: int):
    """Qisqa bazis (Hankerson et al., Alg. 3.74): a_i + b_i*lam ≡ 0 (mod n)."""
    rs, ts = [n, lam], [0, 1]
    while rs[-1] != 0:
        q = rs[-2] // rs[-1]
        rs.append(rs[-2] - q * rs[-1])
        ts.append(ts[-2] - q * ts[-1])
    s = isqrt(n)
    l = max(i for i in range(len(rs)) if rs[i] >= s)
    a1, b1 = rs[l + 1], -ts[l + 1]
    if rs[l] ** 2 + ts[l] ** 2 <= rs[l + 2] ** 2 + ts[l + 2] ** 2:
        a2, b2 = rs[l], -ts[l]
    else:
        a2, b2 = rs[l + 2], -ts[l + 2]
    return a1, b1, a2, b2


def _round_div(a: int, b: int) -> int:
    return (2 * a + b) // (2 * b)


def glv_decompose(k: int, n: int, basis):
    a1, b1, a2, b2 = basis
    c1 = _round_div(b2 * k, n)
    c2 = _round_div(-b1 * k, n)
    k1 = k - c1 * a1 - c2 * a2
    k2 = -c1 * b1 - c2 * b2
    return k1, k2


class GLV(Algorithm):
    name = "GLV"
    only_curves = {"secp256k1"}

    def __init__(self, w: int):
        self.w = w
        self._basis = {}

    @property
    def label(self):
        return f"GLV+wNAF(w={self.w})"

    def table_points(self, curve):
        return 2 * (1 << (self.w - 2)) - 1  # P jadvali + phi(P) jadvali

    def recode(self, k, curve):
        if curve.name not in self._basis:
            self._basis[curve.name] = glv_basis(curve.n, curve.lam)
        k1, k2 = glv_decompose(k % curve.n, curve.n, self._basis[curve.name])
        s1 = -1 if k1 < 0 else 1
        s2 = -1 if k2 < 0 else 1
        d1 = wnaf_digits(abs(k1), self.w)
        d2 = wnaf_digits(abs(k2), self.w)
        L = max(len(d1), len(d2))
        d1 += [0] * (L - len(d1))
        d2 += [0] * (L - len(d2))
        if s1 < 0:
            d1 = [-d for d in d1]
        if s2 < 0:
            d2 = [-d for d in d2]
        return (d1, d2)

    def precompute(self, curve, P):
        tab, ntab = WNAF(self.w).precompute(curve, P)
        ptab = [curve.phi_aff(Q) for Q in tab]
        return (tab, ntab, ptab, _neg_table(curve, ptab))

    def main(self, curve, rec, tabs):
        d1, d2 = rec
        t1, n1, t2, n2 = tabs
        dbl, madd = curve.dbl, curve.madd
        R = None
        for i in range(len(d1) - 1, -1, -1):
            R = dbl(R)
            a = d1[i]
            if a > 0:
                R = madd(R, t1[a >> 1])
            elif a < 0:
                R = madd(R, n1[(-a) >> 1])
            b = d2[i]
            if b > 0:
                R = madd(R, t2[b >> 1])
            elif b < 0:
                R = madd(R, n2[(-b) >> 1])
        return R


# --------------------------------------------------------------------------- #
#  Comb (Lim–Lee), fiksirlangan baza
# --------------------------------------------------------------------------- #
class Comb(Algorithm):
    name = "Comb"
    needs_fixed_base = True

    def __init__(self, w: int):
        self.w = w

    def table_points(self, curve):
        return (1 << self.w) - 2

    def _d(self, curve):
        tb = curve.n.bit_length()
        return -(-tb // self.w)

    def recode(self, k, curve):
        d = self._d(curve)
        w = self.w
        cols = []
        for i in range(d):
            u = 0
            for j in range(w):
                u |= ((k >> (j * d + i)) & 1) << j
            cols.append(u)
        return cols

    def precompute(self, curve, P):
        w = self.w
        d = self._d(curve)
        base = []
        cur = curve.to_jac(P)
        for j in range(w):
            base.append(cur)
            if j < w - 1:
                for _ in range(d):
                    cur = curve.dbl(cur)
        m = (1 << w) - 1
        jac = [None] * (m + 1)
        for j in range(w):
            jac[1 << j] = base[j]
        for u in range(1, m + 1):
            if jac[u] is None:
                hb = 1 << (u.bit_length() - 1)
                jac[u] = curve.add(jac[u ^ hb], jac[hb])
        return (curve.batch_to_affine(jac[1:]), None)

    def main(self, curve, rec, tab):
        tab = tab[0]
        dbl, madd = curve.dbl, curve.madd
        R = None
        for u in reversed(rec):
            R = dbl(R)
            if u:
                R = madd(R, tab[u - 1])
        return R


def build_algorithms(curve_name: str, scenario: str, wnaf_ws, fw_ws, glv_ws, comb_ws):
    algs = [Binary()]
    algs += [WNAF(w) for w in wnaf_ws]
    if scenario == "variable":
        algs += [FixedWindow(w) for w in fw_ws]
        algs.append(Ladder())
    if curve_name == "secp256k1":
        algs += [GLV(w) for w in glv_ws]
    if scenario == "fixed":
        algs += [Comb(w) for w in comb_ws]
    return algs
