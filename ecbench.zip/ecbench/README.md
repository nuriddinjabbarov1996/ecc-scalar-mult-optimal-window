# ecbench — skalyar ko‘paytirish bo‘yicha yagona tajriba bazasi

Bu dastur dissertatsiyadagi barcha raqamlarni **bitta tajribadan, bitta usul bilan** olish uchun yozilgan. Natijalar 3- va 4-boblar, xulosa va kirishdagi ilmiy yangilik uchun yagona manba bo‘ladi.

## Nima o‘lchanadi

| Guruh | Algoritmlar |
|---|---|
| Asosiy | Binary, NAF, wNAF (w = 3…8), Fixed-window (w = 2…6), Montgomery ladder |
| Zamonaviy | GLV + wNAF (faqat secp256k1, w = 3…6), Lim–Lee comb (fiksirlangan baza G, w = 2…8) |
| Real kutubxonalar | OpenSSL (`cryptography` orqali), libsecp256k1 (`coincurve` orqali) |

- Koordinatalar: Jacobian (EFD formulalari), jadval Montgomery hiylasi bilan affinga o‘tkaziladi, asosiy siklda aralash qo‘shish (madd).
- Egri chiziqlar: secp256k1 (a = 0) va NIST P-256 (a = −3).
- Har bir ko‘paytirishda uch bosqich vaqti alohida yoziladi: kodlash, oldindan hisoblash, asosiy sikl.
- Skalyarlar: har bir uzunlik (64, 128, 192, 256 bit) uchun 50 ta turli skalyar, har biri 20 marta. Algoritmlar tartibi har safar tasodifiy aralashtiriladi.
- Amallar soni (dbl, add, madd, inversiya, normallashtirish) alohida sanovchi rejimda yoziladi.
- To‘g‘rilik: har bir algoritm natijasi mustaqil etalon (affin double-and-add) va kutubxonalar bilan solishtiriladi; o‘quv egri chizig‘ida [13]P = (16, 4) tekshiriladi.

## O‘rnatish

Python 3.10 yoki undan yangi versiya kerak.

```
pip install -r requirements.txt
```

`gmpy2` va `coincurve` o‘rnatilmasa ham dastur ishlaydi, lekin ularsiz natijalar to‘liq bo‘lmaydi (gmpy2 — tezlik, coincurve — libsecp256k1 bilan solishtirish). O‘rnatishda xato chiqsa, xato matnini yuboring.

## Ishga tushirish

1. **Sinov (2–3 daqiqa):**
   ```
   python bench.py --quick --out results_quick
   ```
   Oxirida `xato: 0` chiqishi kerak.

2. **To‘liq tajriba (kompyuterga qarab 10–40 daqiqa):**
   ```
   python bench.py
   ```

3. **Tahlil:**
   ```
   python analyze.py
   ```

Windows’da hammasini `run_all.bat`, Linux/macOS’da `./run_all.sh` bilan bitta buyruqda bajarish mumkin.

## O‘lchash sharoiti (natija sifati uchun muhim)

- Noutbuk zaryadlovchiga ulangan, quvvat rejimi “Yuqori unumdorlik” bo‘lsin.
- Brauzer, antivirus skanerlash va boshqa og‘ir dasturlarni yoping; tajriba vaqtida kompyuterdan foydalanmang.
- Jupyter emas, oddiy terminal (cmd / PowerShell / Terminal) ishlating.

## Nimani yuborish kerak

`results` va `results_raw` papkalarini bitta zip arxivga joylab yuboring. Eng muhimlari:

- `results/summary.md` — barcha asosiy jadvallar;
- `results/S1…S7_*.csv` va `fig_*.png`;
- `results_raw/env.json`, `tests.csv`, `log.txt`.

`raw.csv` katta bo‘lishi mumkin (10–20 MB); zip qilganda ancha kichrayadi.

## Fayllar

| Fayl | Vazifasi |
|---|---|
| `ec_core.py` | Maydon va Jacobian arifmetikasi, amallarni sanash |
| `algorithms.py` | Barcha skalyar ko‘paytirish algoritmlari |
| `bench.py` | To‘g‘rilik testlari, vaqt, amallar soni, xotira o‘lchovlari |
| `analyze.py` | Statistika (bootstrap 95% CI, Wilcoxon + Holm), optimal w teoremasini tekshirish, xotira budjeti, bashoratlash modeli (guruhlangan CV) |

## Cheklovlar (dissertatsiyada ochiq yozilishi kerak)

Python realizatsiyasi doimiy vaqtli emas va yon kanal hujumlariga chidamlilik uchun mo‘ljallanmagan. U algoritmlarni **o‘zaro** solishtirish va xarajat modelini tekshirish uchun xizmat qiladi. Mutlaq tezlik bo‘yicha amaliy taqqoslash OpenSSL va libsecp256k1 natijalari orqali beriladi.
