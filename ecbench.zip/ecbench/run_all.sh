#!/usr/bin/env bash
# Linux / macOS uchun
set -e
python3 -m pip install -r requirements.txt
python3 bench.py --quick --out results_quick
python3 bench.py --out results_raw
python3 analyze.py --raw results_raw --out results
echo "Tayyor. results va results_raw papkalarini zip qilib yuboring."
