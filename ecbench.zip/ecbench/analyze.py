"""
analyze.py — bench.py natijalaridan dissertatsiya uchun YAGONA raqamlar to'plamini hisoblaydi.

    python analyze.py --raw results_raw --out results

Chiqishlar (results/):
    summary.md                 — barcha asosiy jadvallar (shu faylni yuboring)
    S1_times.csv               — vaqt statistikasi (o'rtacha, mediana, 95% CI, o'lchov shovqini)
    S2_speedup.csv             — Binary ga nisbatan tezlashish, 95% CI, Wilcoxon p (Holm)
    S3_op_costs.csv            — bitta guruh amalining baholangan vaqti (tau), kappa
    S4_density.csv             — wNAF noldan farqli raqamlar zichligi: tajriba va t/(w+1)
    S5_optimal_w.csv           — optimal w: tajriba, teorema (yopiq formula), to'liq saralash
    S6_memory.csv              — xotira budjeti ostida tanlov: tajriba va teorema
    S7_prediction.csv          — bajarilish vaqtini bashoratlash modeli (guruhlangan CV)
    fig_*.png                  — rasmlar
"""
from __future__ import annotations

import argparse
import json
import math
import os

import numpy as np
import pandas as pd

RNG = np.random.default_rng(12345)
NBOOT = 2000

# Maydon amallari (EFD): (M, S); S = 0.8 M deb olinadi (Hankerson et al.)
FIELD = {"dbl_a0": (2, 5), "dbl_am3": (3, 5), "add": (11, 5), "madd": (7, 4), "norm_pt": (6, 1), "phi": (1, 0)}
S_RATIO, I_RATIO = 0.8, 100.0
OPS = ["dbl", "add", "madd", "norm_pt", "inv", "phi"]
CURVE_A = {"secp256k1": 0, "P-256": -3}


# --------------------------------------------------------------------------- #
#  Yordamchi funksiyalar
# --------------------------------------------------------------------------- #
def md_table(df: pd.DataFrame, floatfmt="{:.4g}") -> str:
    cols = list(df.columns)
    out = ["| " + " | ".join(map(str, cols)) + " |", "|" + "---|" * len(cols)]
    for _, r in df.iterrows():
        cells = []
        for c in cols:
            v = r[c]
            if isinstance(v, (float, np.floating)):
                cells.append("" if pd.isna(v) else floatfmt.format(v))
            else:
                cells.append(str(v))
        out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out)


def boot_ci(x, stat=np.mean, n=NBOOT, alpha=0.05):
    x = np.asarray(x, float)
    if len(x) < 2:
        return (np.nan, np.nan)
    idx = RNG.integers(0, len(x), size=(n, len(x)))
    s = np.apply_along_axis(stat, 1, x[idx])
    return (float(np.quantile(s, alpha / 2)), float(np.quantile(s, 1 - alpha / 2)))


def holm(pvals):
    p = np.asarray(pvals, float)
    m = len(p)
    order = np.argsort(p)
    adj = np.empty(m)
    run = 0.0
    for rank, i in enumerate(order):
        run = max(run, (m - rank) * p[i])
        adj[i] = min(1.0, run)
    return adj


def g(w):
    """Teoremadagi chegaraviy funksiya g(w) = 2^(w-2) (w+1)(w+2)."""
    return 2 ** (w - 2) * (w + 1) * (w + 2)


def w_star(t, kappa, q, wmin=2, wmax=8):
    """Teorema 2: w* = min{ w >= 2 : g(w) >= kappa * q * t }  (q = inf -> wmax)."""
    if math.isinf(q):
        return wmax
    for w in range(wmin, wmax + 1):
        if g(w) >= kappa * q * t:
            return w
    return wmax


def w_budget(B, m_p):
    """Lemma 3: qo'shimcha jadval xotirasi M(w) = m_p (2^(w-2) - 1) <= B  =>  w <= 2 + floor(log2(1 + B/m_p))."""
    return 2 + int(math.floor(math.log2(1 + B / m_p) + 1e-12))


def field_cost(curve, row, prefix=("pre_", "main_")):
    dk = "dbl_a0" if CURVE_A.get(curve, 0) == 0 else "dbl_am3"
    tot = 0.0
    for pf in prefix:
        m, s = FIELD[dk]
        tot += row[pf + "dbl"] * (m + S_RATIO * s)
        for op in ("add", "madd", "norm_pt", "phi"):
            m, s = FIELD[op]
            tot += row[pf + op] * (m + S_RATIO * s)
        tot += row[pf + "inv"] * I_RATIO
    return tot


def metrics(y, yhat):
    y, yhat = np.asarray(y), np.asarray(yhat)
    ss_res = np.sum((y - yhat) ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    return dict(R2=1 - ss_res / ss_tot, MAE_ms=np.mean(np.abs(y - yhat)),
                RMSE_ms=np.sqrt(np.mean((y - yhat) ** 2)), MAPE_pct=100 * np.mean(np.abs((y - yhat) / y)))


# --------------------------------------------------------------------------- #
def main(args):
    os.makedirs(args.out, exist_ok=True)
    raw = pd.read_csv(os.path.join(args.raw, "raw.csv"))
    counts = pd.read_csv(os.path.join(args.raw, "counts.csv"))
    mem = pd.read_csv(os.path.join(args.raw, "memory.csv"))
    tests = pd.read_csv(os.path.join(args.raw, "tests.csv"))
    env = json.load(open(os.path.join(args.raw, "env.json"), encoding="utf-8"))
    md = []

    md.append("# Tajriba natijalari (yagona baza)\n")
    md.append(f"- Sana: {env.get('date')}\n- CPU: {env.get('cpu_model', env.get('processor'))}"
              f"\n- Platforma: {env.get('platform')}\n- Python: {env.get('python','').split()[0]}"
              f"\n- gmpy2: {env.get('gmpy2')}\n- OpenSSL: {env.get('openssl')}\n- coincurve: {env.get('coincurve')}\n")
    md.append(f"- To'g'rilik testlari: {int(tests['ok'].sum())} / {len(tests)} muvaffaqiyatli\n")
    md.append(f"- Vaqt o'lchovlari soni: {len(raw)}\n")

    # ---------------- per-skalyar mediana ----------------
    raw["t_reuse_ns"] = raw["t_rec_ns"] + raw["t_main_ns"]
    key = ["curve", "scenario", "t", "scalar_id", "algo", "w", "label"]
    ps = raw.groupby(key).agg(
        rec=("t_rec_ns", "median"), pre=("t_pre_ns", "median"), main_=("t_main_ns", "median"),
        single=("t_total_ns", "median"), reuse=("t_reuse_ns", "median"),
        cv_single=("t_total_ns", lambda x: 100 * x.std(ddof=1) / x.mean() if len(x) > 1 else np.nan),
    ).reset_index()
    for c in ["rec", "pre", "main_", "single", "reuse"]:
        ps[c] = ps[c] / 1e6  # ms

    # ---------------- S1: vaqt statistikasi ----------------
    rows = []
    for (cv, sc, t, lab), d in ps.groupby(["curve", "scenario", "t", "label"]):
        for mode in ("single", "reuse"):
            x = d[mode].values
            lo, hi = boot_ci(x)
            rows.append(dict(curve=cv, scenario=sc, t=t, mode=mode, label=lab, algo=d["algo"].iloc[0],
                             w=d["w"].iloc[0], n_scalars=len(x), mean_ms=x.mean(), median_ms=np.median(x),
                             sd_ms=x.std(ddof=1), ci95_lo=lo, ci95_hi=hi,
                             noise_cv_pct=d["cv_single"].median()))
    S1 = pd.DataFrame(rows)
    S1.to_csv(os.path.join(args.out, "S1_times.csv"), index=False)

    # ---------------- S2: tezlashish ----------------
    try:
        from scipy.stats import wilcoxon
    except Exception:
        wilcoxon = None
    rows = []
    for (cv, sc, t), d in ps.groupby(["curve", "scenario", "t"]):
        b = d[d["algo"] == "Binary"].set_index("scalar_id")
        for mode in ("single", "reuse"):
            grp = []
            for lab, da in d.groupby("label"):
                if lab == "Binary":
                    continue
                da = da.set_index("scalar_id")
                common = b.index.intersection(da.index)
                r = np.log(b.loc[common, mode].values / da.loc[common, mode].values)
                gm = float(np.exp(r.mean()))
                lo, hi = boot_ci(r)
                p = np.nan
                if wilcoxon is not None and len(r) >= 6 and np.any(r != 0):
                    try:
                        p = float(wilcoxon(r).pvalue)
                    except Exception:
                        pass
                grp.append(dict(curve=cv, scenario=sc, t=t, mode=mode, label=lab, n=len(r), speedup=gm,
                                ci95_lo=float(np.exp(lo)), ci95_hi=float(np.exp(hi)),
                                time_saving_pct=100 * (1 - 1 / gm), p_wilcoxon=p))
            if grp:
                pv = [x["p_wilcoxon"] if not pd.isna(x["p_wilcoxon"]) else 1.0 for x in grp]
                for x, a in zip(grp, holm(pv)):
                    x["p_holm"] = a
                rows += grp
    S2 = pd.DataFrame(rows)
    S2.to_csv(os.path.join(args.out, "S2_speedup.csv"), index=False)

    # ---------------- S3: bitta amal vaqti (tau) va kappa ----------------
    from scipy.optimize import nnls

    cnt = counts.copy()
    for op in OPS:
        cnt[op] = cnt.get("pre_" + op, 0) + cnt.get("main_" + op, 0)
    data = ps.merge(cnt, on=["curve", "scenario", "t", "scalar_id", "algo", "w", "label"], how="inner")
    data["y"] = data["pre"] + data["main_"]  # kodlashsiz (u alohida modellanadi)
    taus, rows = {}, []
    for cv, d in data.groupby("curve"):
        X = d[OPS].values.astype(float)
        X = np.column_stack([X, np.ones(len(d))])
        coef, _ = nnls(X, d["y"].values)
        tau = dict(zip(OPS + ["intercept"], coef))
        taus[cv] = tau
        dk = "dbl_a0" if CURVE_A.get(cv, 0) == 0 else "dbl_am3"
        fc = lambda op: FIELD[op][0] + S_RATIO * FIELD[op][1]
        kappa_th = fc("madd") / (fc("add") + fc("norm_pt"))
        kappa_th_glv = fc("madd") / (fc("add") + fc("norm_pt") + fc("phi"))
        denom = tau["add"] + tau["norm_pt"]
        kappa_emp = tau["madd"] / denom if denom > 0 else np.nan
        denom_g = denom + tau["phi"]
        kappa_emp_glv = tau["madd"] / denom_g if denom_g > 0 else np.nan
        tau["kappa_emp"], tau["kappa_th"] = kappa_emp, kappa_th
        tau["kappa_emp_glv"], tau["kappa_th_glv"] = kappa_emp_glv, kappa_th_glv
        rows.append(dict(curve=cv, **{f"tau_{k}_us": v * 1000 for k, v in list(tau.items())[:7]},
                         kappa_emp=kappa_emp, kappa_theory=kappa_th,
                         kappa_emp_glv=kappa_emp_glv, kappa_theory_glv=kappa_th_glv,
                         ratio_dbl_madd_emp=tau["dbl"] / tau["madd"] if tau["madd"] else np.nan,
                         ratio_dbl_madd_theory=fc(dk) / fc("madd")))
    S3 = pd.DataFrame(rows)
    S3.to_csv(os.path.join(args.out, "S3_op_costs.csv"), index=False)

    # ---------------- S4: wNAF zichligi (Lemma 1) ----------------
    wc = counts[(counts["algo"] == "wNAF")].copy()
    wc["nonzero"] = wc["main_madd"] + 1
    S4 = wc.groupby(["curve", "t", "w"]).agg(n=("nonzero", "size"), nonzero_mean=("nonzero", "mean"),
                                             nonzero_sd=("nonzero", "std"), dbl_mean=("main_dbl", "mean")).reset_index()
    S4["theory_t_over_w1"] = S4["t"] / (S4["w"] + 1)
    S4["rel_err_pct"] = 100 * (S4["nonzero_mean"] - S4["theory_t_over_w1"]) / S4["theory_t_over_w1"]
    S4.to_csv(os.path.join(args.out, "S4_density.csv"), index=False)

    # ---------------- S5: optimal w (teorema vs tajriba) ----------------
    qs = [1, 2, 4, 16, 64, math.inf]
    rows = []
    var = ps[ps["scenario"] == "variable"]
    # GLV uchun samarali uzunlik t_GLV = E[l(k1) + l(k2)]; Lemma 1 bo'yicha (nu + 1)(w + 1) orqali baholanadi
    gc_ = counts[(counts["algo"] == "GLV") & (counts["scenario"] == "variable")].copy()
    gc_["teff"] = (gc_["main_madd"] + 1) * (gc_["w"] + 1)
    t_glv = gc_.groupby(["curve", "t"])["teff"].mean().to_dict()
    for (cv, t), d in var.groupby(["curve", "t"]):
        for fam, famname in (("wNAF", "wNAF"), ("GLV", "GLV")):
            df = d[d["algo"] == fam]
            if df.empty:
                continue
            ws = sorted(df["w"].unique())
            piv = {m: df.pivot_table(index="scalar_id", columns="w", values=m) for m in ("rec", "pre", "main_")}
            sids = piv["rec"].index.values
            for q in qs:
                T = piv["rec"] + piv["main_"] + (0 if math.isinf(q) else piv["pre"] / q)
                means = T.mean()
                w_emp = int(means.idxmin())
                # bootstrap barqarorligi
                Tv = T.values
                hits = np.zeros(len(ws))
                for _ in range(500):
                    idx = RNG.integers(0, len(sids), len(sids))
                    hits[np.argmin(Tv[idx].mean(axis=0))] += 1
                stab = hits[ws.index(w_emp)] / 500
                tau = taus[cv]
                k_emp = tau["kappa_emp_glv" if fam == "GLV" else "kappa_emp"]
                k_th = tau["kappa_th_glv" if fam == "GLV" else "kappa_th"]
                t_mod = t_glv.get((cv, t), t) if fam == "GLV" else t
                w_th_emp = w_star(t_mod, k_emp, q, min(ws), max(ws))
                w_th_th = w_star(t_mod, k_th, q, min(ws), max(ws))
                best = means.min()
                regret = lambda w: 100 * (means[w] - best) / best
                rows.append(dict(curve=cv, family=famname, t=t, t_model=round(t_mod, 1), q=q, w_empirical=w_emp, bootstrap_stability=stab,
                                 w_theorem_kappa_emp=w_th_emp, w_theorem_kappa_theory=w_th_th,
                                 regret_theorem_emp_pct=regret(w_th_emp), regret_theorem_th_pct=regret(w_th_th),
                                 **{f"mean_ms_w{w}": means[w] for w in ws}))
    S5 = pd.DataFrame(rows)
    S5.to_csv(os.path.join(args.out, "S5_optimal_w.csv"), index=False)

    # ---------------- S6: xotira budjeti ----------------
    budgets = [0, 64, 128, 256, 512, 1024, 2048, 4096]
    rows = []
    mp_by_curve = {cv: 2 * ((256 + 7) // 8) for cv in ps["curve"].unique()}
    tbytes = mem.drop_duplicates(["curve", "label"]).set_index(["curve", "label"])["table_bytes_payload"]
    for (cv, t), d in var.groupby(["curve", "t"]):
        fam = d[d["algo"].isin(["Binary", "wNAF"])]
        allc = d[~d["algo"].isin(["OpenSSL", "libsecp256k1"])]
        for q in (1, math.inf):
            col = "single" if q == 1 else "reuse"
            meanT = fam.groupby("label")[col].mean()
            meanAll = allc.groupby("label")[col].mean()
            best_unc = meanT.min()
            for B in budgets:
                feas = [l for l in meanT.index if tbytes.get((cv, l), 0) <= B]
                l_emp = meanT[feas].idxmin()
                feasA = [l for l in meanAll.index if tbytes.get((cv, l), 0) <= B]
                l_all = meanAll[feasA].idxmin()
                wB = w_budget(B, mp_by_curve[cv])
                wth = min(w_star(t, taus[cv]["kappa_emp"], q), wB)
                l_th = "NAF" if wth == 2 else f"wNAF(w={wth})"
                if l_th not in meanT.index:
                    l_th = meanT.index[0]
                rows.append(dict(curve=cv, t=t, q=q, budget_B=B, w_B_lemma=wB, choice_empirical=l_emp,
                                 choice_theorem=l_th, agree=int(l_emp == l_th),
                                 regret_theorem_pct=100 * (meanT[l_th] - meanT[l_emp]) / meanT[l_emp],
                                 loss_vs_unconstrained_pct=100 * (meanT[l_emp] - best_unc) / best_unc,
                                 best_any_family=l_all, best_any_ms=meanAll[l_all]))
    S6 = pd.DataFrame(rows)
    S6.to_csv(os.path.join(args.out, "S6_memory.csv"), index=False)

    # ---------------- S7: bashoratlash modeli ----------------
    from sklearn.linear_model import LinearRegression
    from sklearn.model_selection import GroupKFold

    rows, preds_store = [], {}
    data["fieldM"] = data.apply(lambda r: field_cost(r["curve"], r), axis=1)
    data["grp_scalar"] = data["scenario"] + "_" + data["t"].astype(str) + "_" + data["scalar_id"].astype(str)
    for cv, d in data.groupby("curve"):
        d = d.reset_index(drop=True)
        y = d["single"].values
        models = {
            "A: guruh amallari (6 ta son + t)": d[OPS + ["t"]].values.astype(float),
            "B: maydon amallari (M-ekv. + t)": d[["fieldM", "t"]].values.astype(float),
        }
        for mname, X in models.items():
            # (i) ko'rilmagan skalyarlar
            yhat = np.zeros(len(y))
            for tr, te in GroupKFold(n_splits=5).split(X, y, d["grp_scalar"]):
                yhat[te] = LinearRegression(positive=True).fit(X[tr], y[tr]).predict(X[te])
            rows.append(dict(curve=cv, model=mname, validation="5-fold, skalyarlar bo'yicha guruhlangan",
                             n=len(y), n_params=X.shape[1] + 1, **metrics(y, yhat)))
            preds_store[(cv, mname)] = (y, yhat)
            # (ii) ko'rilmagan konfiguratsiya (leave-one-label-out)
            yhat2 = np.zeros(len(y))
            for lab in d["label"].unique():
                te = (d["label"] == lab).values
                yhat2[te] = LinearRegression(positive=True).fit(X[~te], y[~te]).predict(X[te])
            rows.append(dict(curve=cv, model=mname, validation="har bir konfiguratsiya chetda (LOGO)",
                             n=len(y), n_params=X.shape[1] + 1, **metrics(y, yhat2)))
            # (iii) ekstrapolyatsiya: t<256 da o'qitib, t=256 da tekshirish
            dv = (d["scenario"] == "variable").values
            tr = dv & (d["t"] < d["t"].max()).values
            te = dv & (d["t"] == d["t"].max()).values
            if tr.sum() > 10 and te.sum() > 0:
                m = LinearRegression(positive=True).fit(X[tr], y[tr])
                rows.append(dict(curve=cv, model=mname, validation=f"ekstrapolyatsiya: t<{d['t'].max()} -> t={d['t'].max()}",
                                 n=int(te.sum()), n_params=X.shape[1] + 1, **metrics(y[te], m.predict(X[te]))))
    S7 = pd.DataFrame(rows)
    S7.to_csv(os.path.join(args.out, "S7_prediction.csv"), index=False)

    # ---------------- rasmlar ----------------
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        for cv in S5["curve"].unique():
            sub = S5[(S5["curve"] == cv) & (S5["family"] == "wNAF") & (S5["q"] == 1)]
            fig, ax = plt.subplots(figsize=(6.5, 4))
            for _, r in sub.iterrows():
                ws = [int(c[9:]) for c in r.index if c.startswith("mean_ms_w") and not pd.isna(r[c])]
                ys = [r[f"mean_ms_w{w}"] for w in ws]
                ax.plot(ws, ys, marker="o", label=f"t={r['t']}")
                ax.axvline(r["w_theorem_kappa_emp"], ls=":", lw=0.8, color=ax.lines[-1].get_color())
            ax.set_xlabel("oyna kengligi w"); ax.set_ylabel("o'rtacha vaqt, ms (q=1)")
            ax.set_title(f"{cv}: wNAF, nuqtali chiziq — teorema bo'yicha w*"); ax.legend()
            fig.tight_layout(); fig.savefig(os.path.join(args.out, f"fig_optimal_w_{cv}.png"), dpi=150); plt.close(fig)

        for cv in S2["curve"].unique():
            sub = S2[(S2["curve"] == cv) & (S2["scenario"] == "variable") & (S2["t"] == S2["t"].max())
                     & (S2["mode"] == "single")].sort_values("speedup")
            fig, ax = plt.subplots(figsize=(7, 0.32 * len(sub) + 1.2))
            ax.barh(sub["label"], sub["speedup"], xerr=[sub["speedup"] - sub["ci95_lo"], sub["ci95_hi"] - sub["speedup"]])
            ax.axvline(1, color="k", lw=0.8); ax.set_xscale("log")
            ax.set_xlabel("Binary ga nisbatan tezlashish (log shkala), 95% CI")
            ax.set_title(f"{cv}, t=256, ixtiyoriy baza")
            fig.tight_layout(); fig.savefig(os.path.join(args.out, f"fig_speedup_{cv}.png"), dpi=150); plt.close(fig)

        for (cv, mname), (y, yh) in preds_store.items():
            if not mname.startswith("A"):
                continue
            fig, ax = plt.subplots(figsize=(4.5, 4.5))
            ax.scatter(y, yh, s=6, alpha=0.5)
            lim = [min(y.min(), yh.min()), max(y.max(), yh.max())]
            ax.plot(lim, lim, "k--", lw=0.8)
            ax.set_xlabel("o'lchangan, ms"); ax.set_ylabel("bashorat, ms")
            ax.set_title(f"{cv}: model A, ko'rilmagan skalyarlar")
            fig.tight_layout(); fig.savefig(os.path.join(args.out, f"fig_prediction_{cv}.png"), dpi=150); plt.close(fig)
    except Exception as e:
        md.append(f"\n(Rasmlar chizilmadi: {e})\n")

    # ---------------- summary.md ----------------
    md.append("\n## S1. t=256, ixtiyoriy baza, bir martalik rejim (q=1): o'rtacha vaqt\n")
    s = S1[(S1["scenario"] == "variable") & (S1["t"] == S1["t"].max()) & (S1["mode"] == "single")]
    md.append(md_table(s[["curve", "label", "mean_ms", "median_ms", "ci95_lo", "ci95_hi", "sd_ms", "noise_cv_pct"]]
                       .sort_values(["curve", "mean_ms"])))
    md.append("\n\n## S1b. Fiksirlangan baza (G), jadval qayta ishlatiladi (reuse)\n")
    s = S1[(S1["scenario"] == "fixed") & (S1["mode"] == "reuse")]
    md.append(md_table(s[["curve", "label", "mean_ms", "ci95_lo", "ci95_hi"]].sort_values(["curve", "mean_ms"])))
    md.append("\n\n## S2. Binary ga nisbatan tezlashish (ixtiyoriy baza, q=1)\n")
    s = S2[(S2["scenario"] == "variable") & (S2["mode"] == "single")]
    md.append(md_table(s[["curve", "t", "label", "speedup", "ci95_lo", "ci95_hi", "p_holm"]]
                       .sort_values(["curve", "t", "speedup"], ascending=[True, True, False])))
    md.append("\n\n## S3. Bitta amal vaqti (mikrosekund) va kappa\n")
    md.append(md_table(S3))
    md.append("\n\n## S4. wNAF zichligi: noldan farqli raqamlar soni va t/(w+1)\n")
    md.append(md_table(S4[["curve", "t", "w", "n", "nonzero_mean", "theory_t_over_w1", "rel_err_pct"]]))
    md.append("\n\n## S5. Optimal w: tajriba va teorema\n")
    md.append(md_table(S5[["curve", "family", "t", "t_model", "q", "w_empirical", "bootstrap_stability",
                           "w_theorem_kappa_emp", "w_theorem_kappa_theory", "regret_theorem_emp_pct"]]))
    md.append("\n\n## S6. Xotira budjeti ostida tanlov (Binary/NAF/wNAF oilasi)\n")
    md.append(md_table(S6))
    md.append("\n\n## S7. Bajarilish vaqtini bashoratlash\n")
    md.append(md_table(S7))
    md.append("\n")
    with open(os.path.join(args.out, "summary.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(md))
    print(f"Tayyor: {args.out}/summary.md va CSV fayllar.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="results_raw")
    ap.add_argument("--out", default="results")
    main(ap.parse_args())
